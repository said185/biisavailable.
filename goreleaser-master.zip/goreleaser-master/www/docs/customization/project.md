---
title: Project Name
---

The project name is used in the name of the Brew formula, archives, etc.
If none is given, it will be inferred from the name of the GitHub, GitLab, or
Gitea release.

```yaml
# .goreleaser.yml
project_name: myproject
```
