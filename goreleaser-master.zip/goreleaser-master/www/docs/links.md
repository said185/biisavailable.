---
title: Links
---

- Follow the progress on the [GitHub repository](https://github.com/goreleaser/goreleaser)
- Follow [@goreleaser](https://twitter.com/goreleaser) on Twitter for updates
- Ask questions on [StackOverflow](https://stackoverflow.com/questions/tagged/goreleaser)
- For questions, support and general discussion, please use
[GitHub Discussions](https://github.com/goreleaser/goreleaser/discussions);
- [Contributing Guidelines](https://github.com/goreleaser/goreleaser/blob/master/CONTRIBUTING.md)

This project adheres to the Contributor Covenant
[code of conduct](https://github.com/goreleaser/goreleaser/blob/master/CODE_OF_CONDUCT.md).
By participating, you are expected to uphold this code.
