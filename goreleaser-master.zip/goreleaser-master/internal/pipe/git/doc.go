// Package git implements the Pipe interface getting and validating the
// current git repository state
package git
