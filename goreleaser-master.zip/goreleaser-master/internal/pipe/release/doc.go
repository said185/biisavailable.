// Package release implements Pipe and manages github releases and its
// artifacts.
package release
