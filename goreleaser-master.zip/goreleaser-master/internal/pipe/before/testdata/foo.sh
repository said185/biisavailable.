#!/bin/sh
echo lalala
exit 1
