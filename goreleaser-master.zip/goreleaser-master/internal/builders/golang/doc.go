// Package golang provides a Builder implementation for golang.
package golang
